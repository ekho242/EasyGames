<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3;url=index.php">
    <title>Logout - Easy Games</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        p {
            margin-top: 50px;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <p>Logout feito. Redirecionando para a tela inicial...</p>
</body>
</html>
